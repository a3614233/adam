# 台灣水泥 Playbooks

以(1)資產管理盤點及(2) 合規性檢查(組態管理) 寫playbook。

